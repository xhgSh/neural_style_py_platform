<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>

</script>

<style>


.center-button {
  padding: 10px 20px;
  font-size: 16px;
  cursor: pointer;
}
</style>